﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using System;

public class PlayerController : MonoBehaviour {
    private Rigidbody rb;
    public float speed;
    private int count;
    public Text countText;
    public Text winText;
    public int numberOfPickups;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        count = 0;
        printPoints();
        winText.text = "";
    }
    void FixedUpdate()
    {
        float moveH = Input.GetAxis("Horizontal");
        float moveV = Input.GetAxis("Vertical");
        Vector3 v3 = new Vector3(moveH, 0.0f, moveV);

        rb.AddForce(v3 * speed);
        if (Math.Abs(rb.velocity.y) > 10.0f)
        {
            rb.position = new Vector3(0, 0.1f, 0);
            stopObject();
        }
        if (count == numberOfPickups)
            stopObject();
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pickup"))
        {
            other.gameObject.SetActive(false);
            ++count;
            printPoints();
        }  
    }
    void printPoints()
    {
        countText.text = "Bodovi: " + count.ToString();
        if (count == numberOfPickups)
        {
            winText.text = "Ko je babo?";
            stopObject();
            speed = 0.0f;
        }
    }
    void stopObject()
    {
        rb.velocity = Vector3.zero;
        rb.rotation = Quaternion.Euler(0, 0, 0);
    }
}
